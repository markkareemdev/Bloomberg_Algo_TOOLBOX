s1 = set("palantir")
s2 = set("paiantir")

print(s1 ^ s2)